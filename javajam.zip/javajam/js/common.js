$(document).ready(function () {
    $('#mugclub').hover(function () {
        alert("JavaJam Mug Club Members get a 10% discount on each cup of coffee!");
    });
});